const form = document.querySelector("#order");
const capacity = document.querySelector("#capacity");
const div = document.querySelector("#result");

/*
1) Odrediti artikle koji vise nisu na stanju
2) Odrediti ukupnu tezinu svih tih artikala
3) Ako je ta tezina manja od kapaciteta kamiona, onda:
   3.1) Odrediti i ispisati ukupnu cenu svih tih artikala
   3.2) Inace, ispisati poruku da kamion nema trazeni kapacitet.
*/

/*
function dohvatiZalihe() {
    let request = new XMLHttpRequest();
    request.addEventListener("readystatechange", function() {
        if(request.readyState === 4 && request.status === 200) {
            // sve ok, obradi zahtev
            let data = JSON.parse(request.responseText);
            // ovde ide kod koji obradjuje zalihe
        }
        else if(request.readyState === 4) {
            // desila se neka greska
            console.log("Desila se greska");
        }
    });
    request.open("GET", "json/stock.json");
    request.send();
}

function dohvatiTezine() {
    let request = new XMLHttpRequest();
    request.addEventListener("readystatechange", function() {
        if(request.readyState === 4 && request.status === 200) {
            // sve ok, obradi zahtev
            let data = JSON.parse(request.responseText);
            // ovde ide kod koji obradjuje tezine
        }
        else if(request.readyState === 4) {
            // desila se neka greska
            console.log("Desila se greska");
        }
    });
    request.open("GET", "json/weights.json");
    request.send();
}

function dohvatiCene() {
    let request = new XMLHttpRequest();
    request.addEventListener("readystatechange", function() {
        if(request.readyState === 4 && request.status === 200) {
            // sve ok, obradi zahtev
            let data = JSON.parse(request.responseText);
            // ovde ide kod koji obradjuje cene
        }
        else if(request.readyState === 4) {
            // desila se neka greska
            console.log("Desila se greska");
        }
    });
    request.open("GET", "json/prices.json");
    request.send();
}

dohvatiZalihe();
// cekaj da se zavrsi asinhrona f-ja
dohvatiTezine();
// cekaj da se zavrsi asinhrona f-ja
dohvatiCene();
// cekaj da se zavrsi asinhrona f-ja
// ispisi ukupnu cenu

Ovaj pristup nije tacan!!!!!
Nama su potrebne "komande" koje cekaju da se zavrsi poziv asinhrone f-je da bi se krenulo sa pozivom druge
Nema takvih komandi, ali ima callback funkcija!
*/


function getItems(resource, resolve, reject) {
    let request = new XMLHttpRequest();
    request.addEventListener("readystatechange", function() {
        if(request.readyState === 4 && request.status === 200) {
            // sve ok, obradi zahtev
            let data = JSON.parse(request.responseText);
            resolve(data);  // funkcija radi nesto sa podacima koji su stigli sa servera
        }
        else if(request.readyState === 4) {
            // desila se neka greska
            reject("Desila se greska");
        }
    });
    request.open("GET", resource);
    request.send();
}

function submitFormVarijanta1(event) {
    event.preventDefault();
    // 1) Odrediti artikle koji vise nisu na stanju
    let nizArtikala = [];

    getItems("json/stock.json", (data) => {
        data.forEach(artikal => {
            if(artikal.stock == 0) {
                nizArtikala.push(artikal.id);
            }
        });
        console.log(nizArtikala);
    }, (msg) => {
        div.innerHTML = msg;
    });

    // 2) Odrediti ukupnu tezinu svih tih artikala
    // 3) Ako je ta tezina manja od kapaciteta kamiona, onda:
    // 3.1) Odrediti i ispisati ukupnu cenu svih tih artikala
    // 3.2) Inace, ispisati poruku da kamion nema trazeni kapacitet.
}

form.addEventListener("submit", submitFormVarijanta1);